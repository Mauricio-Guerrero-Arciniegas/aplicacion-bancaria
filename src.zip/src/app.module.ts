import { Module } from '@nestjs/common';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { SequelizeModule } from '@nestjs/sequelize';

// importa tus módulos aquí (ej: UsersModule, TransactionsModule)

@Module({
  imports: [
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    SequelizeModule.forRootAsync({
      imports: [ConfigModule],
      inject: [ConfigService],
      useFactory: async (config: ConfigService) => ({
        dialect: 'postgres',
        host: config.get<string>('DATABASE_HOST') ?? 'localhost',
        port: parseInt(config.get<string>('DATABASE_PORT') ?? '5432', 10),
        username: config.get<string>('DATABASE_USERNAME') ?? 'postgres',
        password: config.get<string>('DATABASE_PASSWORD') ?? '',
        database: config.get<string>('DATABASE_NAME') ?? 'testdb',
        autoLoadModels: true,
        synchronize: true, // 👀 en producción cámbialo a false
        dialectOptions: {
          ssl: {
            require: true,
            rejectUnauthorized: false, // importante para NeonDB
          },
        },
        logging: false, // opcional, para evitar logs largos de SQL
      }),
    }),
  ],
 
})
export class AppModule {}